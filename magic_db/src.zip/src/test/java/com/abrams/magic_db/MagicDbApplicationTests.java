package com.abrams.magic_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagicDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
